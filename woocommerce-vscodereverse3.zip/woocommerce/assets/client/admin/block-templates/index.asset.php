<?php return array('dependencies' => array('wc-settings', 'wp-block-editor', 'wp-blocks', 'wp-core-data', 'wp-data', 'wp-element'), 'version' => '533eab5654b0ef457db9');
