

httrack example.com -O /path/to/save/directory
theharvester -d example.com -b google
dirb example.com /path/to/wordlist.txt

java -jar dirbuster.jar -u example.com -w /path/to/wordlist.txt

./Recon.sh example.com

finalrecon example.com