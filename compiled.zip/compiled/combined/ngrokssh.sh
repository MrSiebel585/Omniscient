 #!/bin/bash
 
# Start ngrok and create an SSH tunnel
echo "ngrok tcp 22" | ngrok tcp 22
