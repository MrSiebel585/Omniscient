from fastapi import FastAPI, Request
import uvicorn
import logging
from datetime import datetime
from pathlib import Path

app = FastAPI()
log_file = Path("/opt/singularity/var/log/ai_runtime.log")
log_file.parent.mkdir(parents=True, exist_ok=True)

logging.basicConfig(filename=log_file, level=logging.INFO, format='[%(asctime)s] [AI] %(message)s')

@app.get("/")
async def root():
    msg = "LLM AI Core Runtime is alive."
    logging.info(msg)
    return {"message": msg}

@app.post("/task")
async def run_task(request: Request):
    data = await request.json()
    task = data.get("task", "No task provided")
    response = f"Received AI task: {task}"
    logging.info(response)
    return {"status": "acknowledged", "task": task}

if __name__ == "__main__":
    uvicorn.run("ai_core_runtime:app", host="0.0.0.0", port=9876, reload=False)
