# Centralized AI with FastAPI

Includes JWT auth, voice I/O, and local conversation saving.